/* Author: Dane Clark
 * Course: SNHU CS-305 Software Security
 * Instructor: Dr. Vivian Lyons
 * Date: 08/10/2022
 * 
 * This code is meant to use an cipher algorithm to convert a name in to bytes and then 
 * into a hex to be displayed as a check sum value.
 * 
 * sources referenced:
 * https://www.geeksforgeeks.org/java-program-to-convert-byte-array-to-hex-string/
 * https://mkyong.com/java/java-how-to-convert-bytes-to-hex/
 */

package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class SslServerController {
//parts from: https://www.geeksforgeeks.org/java-program-to-convert-byte-array-to-hex-string/
	//Function to get byte data using SHA-256
	 public static byte[] getHash(String name) throws NoSuchAlgorithmException {
	      
	        //getInstance method is called with hashing SHA-256  
	        MessageDigest md = MessageDigest.getInstance("SHA-256");  
	        
	        // digest() method calculates message digest of name to return byte 
	        return md.digest(name.getBytes(StandardCharsets.UTF_8));  
	    } 
	 
	 // modified: https://mkyong.com/java/java-how-to-convert-bytes-to-hex/
	 // converts bytes into hex
	 public  String bytesToHex(byte[] bytes) {
		    StringBuilder sb = new StringBuilder();
		    for (byte b: bytes) {
		      sb.append(String.format("%02x", b));
		    }
		    // returns contents into a readable string
		    return sb.toString();
		  }
	
	 @RequestMapping("/hash")
	 public String myHash() throws NoSuchAlgorithmException {
		 //Assigns data with new string.
		String data = "Hello, Dane Clark!";
		
		 //parts from https://www.geeksforgeeks.org/java-program-to-convert-byte-array-to-hex-string/
		 // getInstance method is called with hashing SHA  
		MessageDigest md = MessageDigest.getInstance("SHA-256"); 
		
	   // digest() method called to get message byte
	   byte[] hashData = md.digest(data.getBytes(StandardCharsets.UTF_8));  
	   
	   // Assigns checkSum to hashData
	   String checkSum = bytesToHex(hashData);
	   
		 // return will display name, cipher, and hash data. 
	   return "<p>data:"+ data +"\n" + "</p><p>Name of Cipher Algorith: SHA-256" +" " + "Check Sum Value: " + checkSum;
		}
	}
	
